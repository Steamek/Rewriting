//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel3;
        TLabel *Label3;
        TMemo *Memo1;
        TButton *Button2;
        TEdit *Edit2;
        TEdit *Edit1;
        TRichEdit *RichEdit1;
        TRichEdit *RichEdit2;
        TPanel *Panel1;
        TLabel *Label1;
        TPanel *Panel2;
        TRichEdit *RichEdit3;
        TRichEdit *RichEdit4;
        TPanel *Panel4;
        TLabel *Label2;
        TPanel *Panel5;
        TPanel *Panel6;
        TPanel *Panel7;
        TRichEdit *RichEdit5;
        TPanel *Panel8;
        void __fastcall FormPaint(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Button2Click(TObject *Sender);
        void __fastcall Panel4Click(TObject *Sender);
        void __fastcall RichEdit2Change(TObject *Sender);
        void __fastcall RichEdit2KeyDown(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall RichEdit2MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall RichEdit3MouseMove(TObject *Sender,
          TShiftState Shift, int X, int Y);
        void __fastcall Panel2Click(TObject *Sender);
        void __fastcall Panel6Click(TObject *Sender);
        void __fastcall Panel8Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
